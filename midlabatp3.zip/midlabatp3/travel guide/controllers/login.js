var express 	= require('express');
var router 		= express.Router();
var userModel	= require.main.require('./models/user-model');

router.get('/', function(req, res){
	console.log('login page requested!');
	res.render('login/index');
});

router.post('/', function(req, res){
		
		var us ={
			uname: req.body.uname,
			password: req.body.password
		};

		userModel.validate(us, function(status)
		{
			if(status)
			{
				userModel.getByUname(req.body.uname, function(results)
				{
					if(results.type=='admin')
					{
							//res.cookie('username', req.body.uname);
							res.redirect('/adminhome');
					}
					else if(results.type=='scout')
					{
						//res.cookie('username', req.body.uname);
						//req.send()
						res.send('scouthomepage');
					}
					else
					{
						res.send('genersluserhome');
					}
				});
			}
			else
			{
				res.redirect('/login');
			}
		});
});




//Registration
router.get('/registration',function(req,res){
	console.log("Requested : Registration");
	res.render('login/Registration');
});

router.post('/registration',function(req,res){
	var us={
	
		uname		: req.body.uname,
		contno		: req.body.contno,
		password	: req.body.password,
		type		: req.body.type,
	}
	console.log(us);
	userModel.insert(us,function(status){
		if(status){
			console.log(status);
			req.session.uname = req.body.uname;
			res.redirect('/login');
		}
		else{
			res.redirect('/login/registration');				
		}
	});
});




module.exports = router;