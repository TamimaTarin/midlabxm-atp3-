var express = require('express');
var router = express.Router();
//var userModel = require.main.require('./models/user-model');
var placemodel = require.main.require('./models/place-model');
var app=express();