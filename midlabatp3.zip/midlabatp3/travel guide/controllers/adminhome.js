var express = require('express');
var router = express.Router();
var userModel = require.main.require('./models/user-model');
var placemodel = require.main.require('./models/place-model');
var app=express();



router.get('/', function(req, res){
	console.log(req.session.uname);
	userModel.getByUname(req.session.uname, function(result){
		res.render('adminhome/index', {us: result});
	});
});
//adduser
router.get('/addusers', function(req, res){
	
		userModel.getAll(function(results){
			if(results.length > 0){
				res.render('adminhome/addusers');
			}else{
				res.redirect('/adminhome');
			}
		});
});

router.post('/addusers',function(req,res){
	var us={
	
		uname		: req.body.uname,
		contno		: req.body.contno,
		password	: req.body.password,
		type		: req.body.type,
	}
	console.log(us);
	userModel.insert(us,function(status){
		if(status){
			console.log(status);
			req.session.uname = req.body.uname;
			res.redirect('/adminhome');
		}
		else{
			res.redirect('/adminhome/addusers');				
		}
			
	});
});
//view_users
router.get('/view_users', function(req, res){
	
		userModel.getAll(function(results){
			if(results.length > 0){
				res.render('adminhome/view_users', {uslist: results});
			}else{
				res.redirect('/adminhome');
			}
		});
});
//updateuser
router.get('/update/:id', function(req, res){
	userModel.getById(req.params.id, function(result){
		res.render('adminhome/update', {us: result});
	});
});

router.post('/update/:id', function(req, res){
	
		var us= {
		id       : req.params.id,
		uname		: req.body.uname,
		contno		: req.body.contno,
		password	: req.body.password,
		type	: req.body.type,
		};

		userModel.update(us, function(status){
			if(status){
				res.redirect('/adminhome/view_users');
			}else{
				res.redirect('/adminhome/update/'+req.params.id);
			}
		});
});
//placeinfo
router.get('/information', function(req, res){
	
		placemodel.getAll(function(results){
			if(results.length > 0){
				res.render('adminhome/information', {placeinfolist: results});
			}else{
				res.redirect('/adminhome');
			}
		});
});
//deleteuser
router.get('/delete/:id', function(req, res){
	
	var us = {
			id: req.params.id,
			uname: req.body.uname,
			contno: req.body.ename,
			type: req.body.type,
			
		};

		userModel.delete(us, function(status){
			if(status){
				res.redirect('/adminhome/view_users');
			}else{
				res.redirect('/adminhome/delete/'+req.params.id);
			}
		});
});


router.get('/addplace', function(req, res){
	
		placemodel.getAll(function(results){
			if(results.length > 0){
				res.render('adminhome/addplace');
			}else{
				res.redirect('/adminhome');
			}
		});
});

router.post('/addplace',function(req,res){
	var placeinfo={
	
		place		: req.body.place,
		city		: req.body.city,
		cost	: req.body.cost,
		genre	: req.body.genre,
		description		: req.body.description,
	}
	//console.log(placeinfo);
	placemodel.insert(placeinfo,function(status){
		if(status){
			console.log(status);
			//req.session.place = req.body.place;
			res.redirect('/adminhome');
		}
		else{
			res.redirect('/adminhome/addplace');				
		}
			
	});
});
router.get('/deleteplace/:id', function(req, res){
	
	var placeinfo = {
		id       : req.params.id,
		place		: req.body.place,
		city		: req.body.city,
		cost	: req.body.cost,
		genre	: req.body.genre,
		description		: req.body.description,
		};

		placemodel.delete(placeinfo, function(status){
			if(status){
				res.redirect('/adminhome/information');
			}else{
				res.redirect('/adminhome/deleteplace/'+req.params.id);
			}
		});
});


router.get('/updateplace/:id', function(req, res){
	placemodel.getById(req.params.id, function(result){
		res.render('adminhome/updateplace', {placeinfo: result});
	});
});

router.post('/updateplace/:id', function(req, res){
	
		var placeinfo = {
		id       : req.params.id,
		place		: req.body.place,
		city		: req.body.city,
		cost	: req.body.cost,
		genre	: req.body.genre,
		description		: req.body.description,
		};

		placemodel.update(placeinfo, function(status){
			if(status){
				res.redirect('/adminhome/information');
			}else{
				res.redirect('/adminhome/updateplace/'+req.params.id);
			}
		});
});

module.exports = router;