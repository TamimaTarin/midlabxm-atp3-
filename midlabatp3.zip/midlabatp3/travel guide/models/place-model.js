var db = require('./db');

module.exports= {
	
	
	getById : function(id, callback){
		var sql = "select * from placeinfo where id=?";
		db.getResults(sql, [id], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	getAll : function(callback){
		var sql = "select * from placeinfo";
		db.getResults(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	update: function(placeinfo, callback){
		var sql = "update placeinfo set place=?, city=?, cost=?,genre=?,description=? where id=?";
		db.execute(sql, [placeinfo.place, placeinfo.city,placeinfo.cost,placeinfo.genre,placeinfo.description,placeinfo.id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	
	insert: function(placeinfo, callback){
		var sql = "insert into placeinfo values(?,?,?,?,?,?)";
		db.execute(sql, [null, placeinfo.place, placeinfo.city,placeinfo.cost,placeinfo.genre,placeinfo.description], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	/*getByUname: function(place, callback){
		var sql = "select * from us where uname=?";
		db.getResults(sql, [uname], function(result){
			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});
	},*/
	delete: function(placeinfo, callback){
		var sql = "delete from placeinfo where id=?";
		db.execute(sql, [placeinfo.id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getType: function(placeinfo, callback){
		var sql = "select * from placeinfo where place=?";
		db.getResults(sql, [placeinfo.place], function(results){
			if(results.length > 0){
				callback(true);
			}else{
				callback(null);
			}
		});
	}
}