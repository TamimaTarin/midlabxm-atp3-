var db = require('./db');

module.exports= {
	
	validate: function(us, callback){
		var sql ="SELECT * FROM us where uname=? and password=?";
		db.getResults(sql, [us.uname,us.password], function(results){
            if(results.length > 0){
				callback(true);
			}else{
				callback(false);
			}
		});
	},

		update: function(us, callback){
		var sql = "update us set uname=?, contno=?, password=?,type=? where id=?";
		db.execute(sql, [us.uname, us.contno,us.password,us.type,us.id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	
	getById : function(id, callback){
		var sql = "select * from us where id=?";
		db.getResults(sql, [id], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	getAll : function(callback){
		var sql = "select * from us";
		db.getResults(sql, null, function(results){
			if(results.length > 0){
				callback(results);
			}else{
				callback([]);
			}
		});
	},
	
	insert: function(us, callback){
		var sql = "insert into us values(?,?,?,?,?)";
		db.execute(sql, [null, us.uname, us.contno,us.password, us.type], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	/*getByUname: function(uname, callback){
		var sql = "select * from us where uname=?";
		db.getResults(sql, [uname], function(result){
			if(result.length > 0){
				callback(result[0]);
			}else{
				callback(null);
			}
		});
	},*/
	getByUname: function(uname, callback){
		var sql = "select * from us where uname=?";
		db.getResults(sql, [uname], function(results){
			if(results.length > 0){
				callback(results[0]);
			}else{
				callback(null);
			}
		});
	},
	
	delete: function(us, callback){
		var sql = "delete from us where id=?";
		db.execute(sql, [us.id], function(status){
			if(status){
				callback(true);
			}else{
				callback(false);
			}
		});
	},
	getType: function(us, callback){
		var sql = "select * from us where uname=?";
		db.getResults(sql, [us.uname], function(results){
			if(results.length > 0){
				callback(true);
			}else{
				callback(null);
			}
		});
	}
}